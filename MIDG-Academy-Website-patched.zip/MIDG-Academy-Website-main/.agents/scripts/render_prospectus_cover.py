from pathlib import Path

import pymupdf


source = Path("attached_assets/MIDG_Academy_Prospectus_(1)_(1)_1791570312698.pdf")
destination = Path(".agents/outputs/midg-academy-prospectus-cover.png")

document = pymupdf.open(source)
page = document[0]
pixmap = page.get_pixmap(matrix=pymupdf.Matrix(1.6, 1.6), alpha=False)
pixmap.save(destination)
print(f"Rendered page 1 of {document.page_count} to {destination}")
