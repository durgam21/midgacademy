from pathlib import Path

import fitz

pdf_path = Path("attached_assets/MIDG_Academy_Prospectus_(1)_1791050959724.pdf")
output_dir = Path(".agents/outputs/prospectus")
output_dir.mkdir(parents=True, exist_ok=True)

doc = fitz.open(pdf_path)
columns = 3
cell_width = 320
cell_height = 430
rows = (len(doc) + columns - 1) // columns
sheet_doc = fitz.open()
sheet_page = sheet_doc.new_page(width=columns * cell_width, height=rows * cell_height)

for index, page in enumerate(doc):
    pixmap = page.get_pixmap(matrix=fitz.Matrix(0.55, 0.55), alpha=False)
    image_path = output_dir / f"page-{index + 1:02}.png"
    pixmap.save(image_path)
    image_rect = fitz.Rect(
        (index % columns) * cell_width + 10,
        (index // columns) * cell_height + 10,
        (index % columns + 1) * cell_width - 10,
        (index // columns + 1) * cell_height - 34,
    )
    sheet_page.insert_image(image_rect, filename=str(image_path), keep_proportion=True)
    sheet_page.insert_text(
        ((index % columns) * cell_width + 12, (index // columns + 1) * cell_height - 12),
        f"Page {index + 1}",
        fontsize=11,
        color=(0, 0, 0),
    )

sheet_pixmap = sheet_page.get_pixmap(matrix=fitz.Matrix(1, 1), alpha=False)
sheet_pixmap.save(output_dir / "contact-sheet.png")
sheet_doc.close()
print(f"Rendered {len(doc)} pages to {output_dir}; contact sheet: {output_dir / 'contact-sheet.png'}")